@extends('layouts.backend.master')

@section('title', 'Welcome to CoffeeTrip')

@section('content')
<div class="container mx-auto mt-8">
    <h2 class="text-2xl font-semibold">Welcome to CoffeeTrip</h2>
    <p class="mt-4">This is where your content goes. You can add anything here.</p>
</div>
@endsection
